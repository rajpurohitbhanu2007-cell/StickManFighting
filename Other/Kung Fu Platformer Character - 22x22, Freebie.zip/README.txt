+====================================================================+
|  KUNG FU PLATFORMER CHARACTER [22x22] — README (FREEBIE VERSION)   |
+====================================================================+

READ ME FIRST
----------------------------------------------------------------------
Please read carefully for a smoother usage in your game engine. :)

ANIMATIONS IN THIS SAMPLE
----------------------------------------------------------------------
- Design loop - 1 frame
- Idle - 14 frames
- Jump Standing - 15 frames (folder with sub-clips)
    - Hop - 6 frames
    - Fall - 3 frames
    - Fall Loop - 3 frames
    - Land - 3 frames
- Run - 8 frames
- Jump Running - 19 frames (folder with sub-clips)
    - Hop - 7 frames
    - Fall - 3 frames
    - Fall Loop - 3 frames
    - Land Running - 2 frames
    - Land Standing - 4 frames
- Jeet Kune Do Fighting Stance - 8 frames
- Side Kick - 7 frames
- Hit - 5 frames

NOTE
----------------------------------------------------------------------
This sample contains 15 of 23 full animations for one of the four
skins available with the premium edition.

DUST VFX
----------------------------------------------------------------------
Provided separately so you can decide when/where to spawn them 
depending on your game environment. Refer to the animated demos 
for context.

TIMING
----------------------------------------------------------------------
Default timing: 12.5 fps (80 ms per frame).

